#ifndef AGENT__
#define AGENT__

#include <string>
#include <iostream>
using namespace std;

// -----------------------------------------------------------
//				class Agent
// -----------------------------------------------------------
class Environment;
class Agent
{
public:
	Agent(int posrobotx, int posroboty, int posobjx, int posobjy){
	}

	enum ActionType
	{
	    actFORWARD,
	    actTURN,
	    actIDLE
	};

	void Perceive(const Environment &env);
	ActionType Think();

private:
};

string ActionStr(Agent::ActionType);

#endif
