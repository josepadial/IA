#include "GUI.h"

int main(int argc, char *argv[]){
	return GUI::startDraw(argc,argv);
}
